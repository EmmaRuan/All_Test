//
//  AdmirePage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/10.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit

class AdmirePage: UIViewController {

    @IBOutlet weak var myAdmireView: UIImageView!
    @IBOutlet weak var showSurprise1: UIImageView!
    @IBOutlet weak var showSurprise2: UIImageView!
    
    let imageArray = ["https://hips.hearstapps.com/del.h-cdn.co/assets/15/25/2013-07-01-despmeminions-586x322_alt.jpg", "https://i.pinimg.com/originals/ca/e1/57/cae157bf8dbffdf5f7015d220db28544.jpg"]
    
    func downloadPics(_ url:String) -> UIImage!{
        let data = try?Data(contentsOf: URL(string: url)!)
        return UIImage(data: data!)
    }
 
    
    
    @IBAction func startDownload(_ sender: UIButton) {
        
        //循序佇列
        let createQueue1 = DispatchQueue(label: "Queue1")
        let createQueue2 = DispatchQueue(label: "Queue2")
        createQueue1.async {
            let downloadView1 = self.downloadPics(self.imageArray[0])
            DispatchQueue.main.async {
                self.showSurprise1.image = downloadView1
            }
        }
        
        createQueue2.async {
            let downloadView2 = self.downloadPics(self.imageArray[1])
            DispatchQueue.main.async {
                self.showSurprise2.image = downloadView2
            }
        }
 
        //共時佇列配其他UI會造成畫面卡住
        //TIC Read Status [11:0x0]: 1:57 ->這個錯誤可能是圖的URL有誤，換新的就解決
        //先下載需要時間的檔案，由上而下執行，執行完才會執行工作2
        /*DispatchQueue.global().async{
         let download1 = self.downloadPics(self.imageArray[0])
         let download2 = self.downloadPics(self.imageArray[1])
         
         //工作2主佇列作畫面更新
         DispatchQueue.main.async {
         self.imageView1.image = download1
         self.imageView2.image = download2
         }
         }
         */
    }

    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

       @IBAction func admirePanAction(_ sender: UIPanGestureRecognizer) {
        if sender.state != .ended{
            let location = sender.location(in: sender.view!)
            myAdmireView.center = location
        }
    }

}
