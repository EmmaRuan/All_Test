//
//  PedometerPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2019/1/8.
//  Copyright © 2019 阮宜停. All rights reserved.
//

import UIKit
import CoreMotion

class PedometerPage: UIViewController {
    @IBOutlet weak var stepLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var ascendLabel: UILabel!
    @IBOutlet weak var descendLabel: UILabel!
   // @IBOutlet weak var altiLabel: UILabel!
    
    //var altimeter:CMAltimeter!
    
    var pedometer:CMPedometer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pedometer = CMPedometer() //產生計步器
        //如果可以計步、記錄距離、爬樓
        if CMPedometer.isStepCountingAvailable() && CMPedometer.isDistanceAvailable() && CMPedometer.isFloorCountingAvailable() {
            pedometer.startUpdates(from: Date(), withHandler: {(data:CMPedometerData?, error:Error?) -> Void in
                print("走路步數: \(data!.numberOfSteps)")
                print("距離: \(String(describing: data!.distance))")
                print("上樓計數: \(String(describing: data!.floorsAscended))")
                print("下樓計數: \(String(describing: data!.floorsDescended))")
                
               
                
                //程式碼更新畫面的文字在main queuee改
                DispatchQueue.main.async(execute: {
                    self.stepLabel.text = "走路步數: \(data!.numberOfSteps)"
                    self.distanceLabel.text = "距離: \(data!.distance!)"
                    self.ascendLabel.text = "上樓計數: \(data!.floorsAscended!)"
                    self.descendLabel.text = "下樓計數: \(data!.floorsDescended!)"
                })
                
            })
            
            pedometer.queryPedometerData(from: Date(timeIntervalSinceNow: -24 * 60 * 60), to: Date(), withHandler:{
                (data:CMPedometerData?, error:Error?) -> Void in
                print("Step(YesterdayTillNow):\(data!.numberOfSteps)")
                print("Distance(YesterdayTillNow): \(String(describing: data!.distance))")
                print("Floor Ascend(FromYesterday:\(String(describing: data!.floorsAscended))")
                print("Floor Descend(FromYesterday):\(String(describing: data!.floorsDescended))")
            })
        }
        
        //高度距離
       /* altimeter = CMAltimeter() //產生測量的高度
        let operationQ = OperationQueue()
        if CMAltimeter.isRelativeAltitudeAvailable(){ //如果可以使用
            
            altimeter.startRelativeAltitudeUpdates(to: operationQ, withHandler: {
                (data:CMAltitudeData?, error:Error?) in
                print("實際高度: \(data!.relativeAltitude) meters")
                
                DispatchQueue.main.async(excute: {
                    self.altiLabel.text = "實際高度: \(Int(truncating: data!.relativeAltitude))"
                    
                })
            })
            
        } */
        

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        //停止更新資料
        pedometer.stopUpdates()
        //altimeter.stopRelativeAltitudeUpdates()
    }

  

}
