//
//  MainPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//
import UIKit
import Foundation
class MainPage: UIViewController {
    @IBOutlet weak var Bear_1: UIImageView!
    @IBOutlet weak var Fries_1: UIImageView!
    @IBOutlet weak var Minion: UIButton!
    @IBOutlet weak var Ketchup: UIButton!
    @IBOutlet weak var FoodsInfo: UIButton!
    
    @IBAction func swipeAction(_ sender: UISwipeGestureRecognizer) {
        print("Just swipe right")
    }
    
    @IBAction func tapAction(_ sender: UITapGestureRecognizer) {
        let touchPoint = sender.location(ofTouch: 0, in:sender.view)
        print("Tap on the Screen: \(touchPoint)")
    }
    
    @IBAction func gotoHome(_ sender: UIBarButtonItem) {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "BabyHome"){
            self.navigationController?.pushViewController(controller, animated: true)        }
        
    }
    

    
    
    @IBAction func Click_foodsIntroduce(_ sender: UIButton) {
        let myAlert = UIAlertController(title: "食物的介紹", message: "小小兵最愛吃的是香蕉！！但這裡只有薯條～", preferredStyle: .alert)
        //建立第一顆按鈕
        let okAction = UIAlertAction(title: "Like", style: .default, handler:{ UIAlertAction -> () in
        print("Like")
            self.dismiss(animated: true, completion: nil)
        })
       //建立第二顆按鈕
        let cancelAction = UIAlertAction(title: "ordinary", style: .default, handler: {(action:UIAlertAction) -> () in
            print("ordinary")
            self.dismiss(animated: true, completion: nil)
        })
        //把第一顆按鈕加入警告控制器
        myAlert.addAction(okAction)
        //把第二顆按鈕加入警告控制器
        myAlert.addAction(cancelAction)
        //推出警告控制器
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func Click_Minion(_ sender: UIButton) {
        let myAlert = UIAlertController(title: "小小兵", message: "一群說奇怪話的小黃人", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Like", style: .default, handler: { UIAlertAction -> () in
            print("Like")
            self.dismiss(animated: true, completion: nil)
        })
        let cancelAction = UIAlertAction(title: "ordinary", style: .default, handler: {(action:UIAlertAction) -> () in
            print("ordinary")
            self.dismiss(animated: true, completion: nil)
        })
        
        myAlert.addAction(okAction)
        myAlert.addAction(cancelAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func Click_Ketchup(_ sender: UIButton) {
        let myAlert = UIAlertController(title: "Hello", message: "Enter your name", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Like", style: .default, handler: { UIAlertAction -> () in
            print("Like")
            self.dismiss(animated: true, completion: nil)
        })
        let cancelAction = UIAlertAction(title: "ordinary", style: .default, handler: {(action:UIAlertAction) -> () in
            print("ordinary")
            self.dismiss(animated: true, completion: nil)
        })
        //加入文字輸入框
        myAlert.addTextField(configurationHandler: {
            (UITextField: UITextField!) -> Void in
            UITextField.placeholder = "Enter your name here!"
        })
        
        myAlert.addAction(okAction)
        myAlert.addAction(cancelAction)
        self.present(myAlert, animated: true, completion: nil)
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        //1.圖的框線顏色、寬度
//        let myImageView = Bear_1
//        myImageView?.layer.borderColor = UIColor.black.cgColor
//        myImageView?.layer.borderWidth = 2.0
        
        
//        //2.整個畫面模糊效果（毛玻璃）
//        let blurEffect = UIBlurEffect(style: .light) //選擇模糊效果
//        let blurView = UIVisualEffectView(effect: blurEffect) //建立模糊視圖
//        blurView.frame = view.frame //設定模糊視圖大小
//        blurView.center = view.center //設定模糊位置
//        view.addSubview(blurView) //把模糊視圖加入畫面
        //圓角
        Bear_1.layer.cornerRadius = 50
        
        //將按鈕置於最上層
        FoodsInfo.bringSubviewToFront(FoodsInfo)
        Minion.bringSubviewToFront(Minion)
        Ketchup.bringSubviewToFront(Ketchup)
        
        //將圖案置於最下層
        Bear_1.sendSubviewToBack(Bear_1)
        Fries_1.sendSubviewToBack(Fries_1)
    }
    
  
    
}
