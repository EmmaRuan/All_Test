//
//  SecondPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation
class SecondPage: UIViewController,  UIPickerViewDelegate ,UITextFieldDelegate, UIPickerViewDataSource {
    @IBOutlet weak var myDatePicker: UIDatePicker!
    @IBOutlet weak var myText: UITextField!
    
    @IBAction func myDatePickerAction(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy MM dd EE HH:mm" //設定顯示的日期格式
        myText.text = dateFormatter.string(from: myDatePicker.date) //更新TextField內容
        
        //print(dateFormatter.string(from: myDatePicker.date))
    }
    
    @IBAction func goHomePage(_ sender: UIBarButtonItem) {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "BabyHome"){
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myText.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //按下return讓鍵盤消失
        myText.resignFirstResponder()
        print("按下Done")
        return false
    }
    
    // 點擊背景，鍵盤消失
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(false)
    }

    
    let numberArray = ["1","2","3","4","5","6","7","8","9","10"]
    let fruitArray = ["apple","banana","mango","watermelon"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2 //有多少component
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //設定每個component 有幾列
        if component == 0{
            return numberArray.count //第一個Component要顯示的數量
        }
        else{
            return fruitArray.count //第二個Component要顯示的數量
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return numberArray[row] //第一個Component要顯示的文字
        }else{
            return fruitArray[row] //第二個Component要顯示的文字
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            print("number: \(numberArray[row])") //點擊第一個Component
        }else{
            print("fruit: \(fruitArray[row])") //點擊第二個Component
        }
        
    }
    


    
    
    
   
}
