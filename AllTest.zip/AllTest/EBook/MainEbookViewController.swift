//
//  MainEbookViewController.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/11/26.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit

class MainEbookViewController: UIViewController , UIPageViewControllerDataSource{
    
    //前頁
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let vc = viewController as! EbookViewController
        var index = vc.nowPageNumber as Int
        if index == 0 || index == NSNotFound{
            return nil
        }
        index -= 1
        return self.viewControllerAtIndex(index: index)
    }
    
    //後頁
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let vc = viewController as! EbookViewController
        var index = vc.nowPageNumber as Int
        if index == NSNotFound {
            return nil
        }
        index += 1
        if index >= 3 {
            return nil
        }
        return self.viewControllerAtIndex(index: index)
    }
    

    //增加PageViewController屬性
    var pageViewController:UIPageViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //產生PageViewController存在類別的pageViewController屬性中
        self.pageViewController = self.storyboard?.instantiateViewController(withIdentifier: "pageviewController") as? UIPageViewController
        //設定自己為pageviewcontroller的datasource，告知要顯示的內容
        self.pageViewController.dataSource = self
        //設定開始頁面
        let startPage = self.viewControllerAtIndex(index:0) as EbookViewController

        let viewControllers = [startPage]
        self.pageViewController.setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
        self.pageViewController.view.frame = self.view.frame
        self.addChild(self.pageViewController)
        self.view.addSubview(self.pageViewController.view)
        self.pageViewController.didMove(toParent: self)
        
    }
    
    func viewControllerAtIndex(index:Int) -> EbookViewController {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "maincontentviewcontroller") as! EbookViewController
        vc.nowPageNumber = index
        return vc
    }
  

}
