//
//  EbookViewController.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/11/23.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit

class EbookViewController: UIViewController {
    
    var nowPageNumber = 0 //記錄目前顯示頁數
    @IBOutlet weak var mainImage: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //畫面上ImageView圖片依照nowPageNumber改變
        mainImage.image = UIImage(named: "\(nowPageNumber)")

    }
 
    
    

   
}
