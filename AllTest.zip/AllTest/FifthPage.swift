//
//  FifthPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation

class FifthPage: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

