//
//  SixthPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation
class SixthPage: UIViewController {
    
    @IBOutlet weak var knob: UIImageView!
    @IBOutlet weak var myRocketView: UIImageView!
    
    //拖曳
    @IBAction func panAction(_ sender: UIPanGestureRecognizer) {
        if sender.state != .ended{
            let location = sender.location(in: sender.view!)
            myRocketView.center = location
        }
    }

    
    var nowAngle:CGFloat = 0
    
    //計算畫面上兩點的距離
    func distanceBetweenPoints(point1:CGPoint, point2:CGPoint) -> CGFloat{
        let dx = point1.x - point2.x
        let dy = point1.y - point2.y
        return sqrt(dx * dx + dy * dy)
    }

    //計算角度，得到兩條線的夾角
    func angleBetweenLines(lineABegin:CGPoint, lineAEnd:CGPoint, lineBBegin:CGPoint, lineBEnd:CGPoint) -> CGFloat{
        let a = lineAEnd.x - lineABegin.x
        let b = lineAEnd.y - lineABegin.y
        let atanA = atan2(a,b) //第一條線形成的角度

        let c = lineBEnd.x - lineBBegin.x
        let d = lineBEnd.y - lineBBegin.y
        let atanB = atan2(c,d) //第二條線形成的角度

        return (atanA - atanB) * 180 / CGFloat (CGFloat.pi) //得到相差徑度，乘180除M_PI已廢除（使用'Double.pi'或'.pi'）得到角度

    }

    //實作旋鈕
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let nowPoint = touches.first?.location(in: self.view)
        let previousPoint = touches.first?.previousLocation(in: self.view)
        let midPoint = knob.center
        let distance = distanceBetweenPoints(point1: midPoint, point2: nowPoint!)
        if distance < knob.bounds.size.width/2{
            let angle = angleBetweenLines(lineABegin: midPoint, lineAEnd: previousPoint!, lineBBegin: midPoint, lineBEnd: nowPoint!)

            nowAngle += angle
            knob.transform = CGAffineTransform(rotationAngle: nowAngle * .pi / 180)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //支援多點觸碰
        view.isMultipleTouchEnabled = true
    }
}
