//
//  WebViewPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2019/1/14.
//  Copyright © 2019 阮宜停. All rights reserved.
//

import UIKit

class WebViewPage: UIViewController {

    @IBOutlet weak var myWebview: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //網址
        let address = "http://www.minionshop.co.uk"
        let addressURL = URL(string: address) //用網址產生URL
        if let url = addressURL{
            let request = URLRequest(url: url) //用URL產生URLRequest
            myWebview.loadRequest(request)  //Webview讀取Request
        }
        /*
        
        //顯示網頁程式碼
        myWebview.loadHTMLString("<h1>Hello</h1><p>What's up?</p>", baseURL: nil)
 
        
        //讀取專案中Html檔
        if let htmlFile = Bundle.main.path(forResource: "index", ofType: "html"){
            do{
                let html = try String(contentsOfFile: htmlFile, encoding: String.Encoding.utf8)
                myWebview.loadHTMLString(html, baseURL: nil)
            }catch{
                print("讀取發生錯誤")
            }
        }
 
        //顯示各種檔案Word PDF Txt(bundle大部分都是匯入專案的檔案)
        let pdfPath = Bundle.main.path(forResource: "BookInfo", ofType: "pdf")
        let url = URL(fileURLWithPath: pdfPath!)
        myWebview.loadRequest(URLRequest(url: url))
    */
        
    }
    

   
}
