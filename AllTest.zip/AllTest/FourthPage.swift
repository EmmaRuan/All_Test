//
//  FourthPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation
class Fourth: UIViewController, UIScrollViewDelegate {
//    @IBOutlet weak var ShowPic: UIImageView!
    @IBOutlet weak var ColorScrollView: UIScrollView!
    @IBOutlet var myPageControl2: UIPageControl!
    
    @IBAction func myPageControlAction(_ sender: UIPageControl) {
        print(sender.currentPage)
        //取得選取頁面
        let currentPageNumber = sender.currentPage
        //把ScrollView的寬度存在Width變數後，依目前頁面算出需要的偏離距離
        let width = ColorScrollView.frame.size.width
        //讓ScrollView移動到正確位置
        let offset = CGPoint(x: width * CGFloat(currentPageNumber), y: 0)
        ColorScrollView.setContentOffset(offset, animated: true)
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        //計算目前滑動頁數
        let currentPageNumber = Int(round(ColorScrollView.contentOffset.x / scrollView.frame.size.width))
        myPageControl2.currentPage = currentPageNumber
    }
    
    
    override func viewDidLoad() {
    super.viewDidLoad()
        myPageControl2.currentPage = 1
        ColorScrollView.contentSize.width = 1080
        ColorScrollView.contentSize.height = 1080
        ColorScrollView.minimumZoomScale = 1.0
        ColorScrollView.maximumZoomScale = 5.0
        
    }
//
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return ShowPic
//    }
    
    override func viewDidLayoutSubviews() {
        //建立PageControl
        myPageControl2 = UIPageControl(frame: CGRect(x: view.frame.size.width/2 - 30, y: view.frame.size.height - 50, width: 60, height: 37))
        //設定PageControl顏色
        myPageControl2.pageIndicatorTintColor = UIColor.black
        //設定目前頁面的顏色
        myPageControl2.currentPageIndicatorTintColor = UIColor.lightGray
        //設定總頁數
        myPageControl2.numberOfPages = 3
        //設定目前頁數
        myPageControl2.currentPage = 0
        //設定改動頁數要執行的方法
        myPageControl2.addTarget(self, action: #selector(Fourth.myPageControlAction(_:)), for: .valueChanged)
        //把PageControl加到畫面上
        view.addSubview(myPageControl2)
        
        //設定contnetSize.width
        ColorScrollView.contentSize.width = ColorScrollView.frame.width * 6
        // 設定三個畫面顏色
        let viewColors = [UIColor.red, UIColor.yellow, UIColor.blue]
        //在ScrollView上加入三個畫面(平行)
        for i in 0..<3 {
            let oneView = UIView(frame: CGRect(x: CGFloat(i) * ColorScrollView.frame.size.width, y: 0, width: ColorScrollView.frame.size.width, height: ColorScrollView.frame.size.height))
            oneView.backgroundColor = viewColors[i]
            
            ColorScrollView.addSubview(oneView)
        }
        //設定PageEnable
        ColorScrollView.isPagingEnabled = true
        //設定bounce
        ColorScrollView.bounces = false
    }
}

