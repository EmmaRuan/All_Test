//
//  CompassPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/24.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import CoreLocation

class CompassPage: UIViewController, CLLocationManagerDelegate {
    
    let canvasView = CanvasView()
    let locationManger = CLLocationManager()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        canvasView.frame.size = CGSize(width: view.bounds.width, height: view.bounds.width)
        canvasView.center = view.center
        canvasView.backgroundColor = .clear
        view.addSubview(canvasView)
        

        locationManger.delegate = self
        locationManger.startUpdatingLocation()
        locationManger.startUpdatingHeading()


    }
    
    func locationmanager(_ manager: CLLocationManager, didupdateHeading newHeading: CLHeading){
        
       let angle = newHeading.magneticHeading * 3.14159 / 180
        //newHeading.trueHeading * .pi / 180
        print(newHeading.magneticHeading)
        UIView.animate(withDuration: 0.5){
            self.canvasView.transform = CGAffineTransform(rotationAngle: -CGFloat(angle)) //傳入的角度為負數，表示逆時針旋轉
        }
    }
    

    

}
