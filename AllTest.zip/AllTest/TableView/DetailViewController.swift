//
//  DetailViewController.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/11/21.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    @IBOutlet weak var detailDescriptionLabel: UILabel!
    
    var detailItem: AnyObject?{
        didSet{
            self.configureView()
        }
    }
    
    func configureView() {
        if let detail = self.detailItem {
            if let label = self.detailDescriptionLabel{
                label.text = detail.description
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //讓 Label 顯示 configureView 的字
        configureView()
    }
    


}
