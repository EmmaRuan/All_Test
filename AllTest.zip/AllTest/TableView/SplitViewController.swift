//
//  SplitViewController.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/11/21.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit

class SplitViewController: UITableViewController {
    
    var appleProduct: NSMutableArray = ["Minions","Gru","Lucy","Di"]
    var bananaProduct: NSMutableArray = ["Couple","DiShock","Guitar"]
    var allProduct = ["Minions","Gru","Lucy","Di","Couple","DiShock","Guitar"]
    
    @IBOutlet weak var showEdit: UIBarButtonItem! 
    @IBOutlet weak var MyTableView: UITableView!
    
    override func viewDidLoad() {
        //下拉更新
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        
        super.viewDidLoad()
        self.tableView.contentInset = UIEdgeInsets(top: 5.0, left: 0, bottom: 0, right: 0)
        
        navigationItem.leftBarButtonItem = editButtonItem
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: nil)
        navigationItem.rightBarButtonItem = addButton
        
        
    }
    
    @objc func  handleRefresh() {
        
        tableView.refreshControl?.endRefreshing()
        tableView.reloadData()
        
    }

   
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0{
            return "Section 1"
        }
        else{
            return"Section 2"
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50

    }

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        //TableView 顯示2個section
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //TableView 顯示單列
//        return appleProduct.count
        //顯示2列
        if section == 0 {
            return appleProduct.count
        }
        else{
            return bananaProduct.count
        }
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("select section: \(indexPath.section)")
        print("select row: \(indexPath.row)")
        if indexPath.section == 0 {
            print("select appleProduct name: \(appleProduct[indexPath.row]) ")
        }else{
            print("select bananaProduct name: \(bananaProduct[indexPath.row])")
            //取消選取狀態
            tableView.self.deselectRow(at: indexPath, animated: false)
            
            
        }
    }
    

    //表格UI相關都在cellForRowAt改
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        
        //使用預設Label、imageview
//        //設定Cell文字
//        cell.textLabel!.text = appleProduct[indexPath.row]
//        //設定縮圖
//        cell.imageView?.image = UIImage(named: appleProduct[indexPath.row])
        
        //使用客製化要開一個cell把相關按鈕連結
        if indexPath.section == 0 {
            cell.cellLabel.text = appleProduct[indexPath.row] as? String
            //設定縮圖
            cell.cellImage.image = UIImage(named: appleProduct[indexPath.row] as! String)
        }
        else{
            cell.cellLabel.text = bananaProduct[indexPath.row] as? String
            //設定縮圖
            cell.cellImage.image = UIImage(named: bananaProduct[indexPath.row] as! String)
        }
        
        return cell
    }

 /*       override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            appleProduct.remove(at: indexPath.row)
            bananaProduct.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.reloadData()
        }
    }
*/
    

    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
//        let shareAction = UITableViewRowAction(style: .normal, title: "Share", handler: {
//            (action,indexPath) in
//            print("Share")
//            tableView.isEditing = false
//        })
//        shareAction.backgroundColor = UIColor.gray
        
        let doneAction = UITableViewRowAction(style: .normal, title: "Done", handler: {
            (action,indexPath) -> Void in
            print("Done")
            tableView.isEditing = false
        })
        doneAction.backgroundColor = UIColor.blue
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete", handler: {
            (action,indexPath)  in
            print("Delete")
//            self.appleProduct.remove(indexPath.row)
//            self.bananaProduct.remove(indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .automatic)
        })
        deleteAction.backgroundColor = UIColor.red
        return [deleteAction, doneAction]
    }
    

    @IBAction func editButtonPress(_ sender: UIBarButtonItem) {
        if MyTableView.isEditing == true
        {
            sender.title = "Edit"
            MyTableView.isEditing = false
        }else{
            sender.title = "Done"
            MyTableView.isEditing = true
        }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        appleProduct.exchangeObject(at: sourceIndexPath.row, withObjectAt: destinationIndexPath.row)
        bananaProduct.exchangeObject(at: sourceIndexPath.row, withObjectAt: destinationIndexPath.row)
    }
    
    
    
    //按下TableView執行PrepareForSegue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
        
        if segue.identifier == "showDetail" {
            if let indexpath = self.tableView.indexPathForSelectedRow{
                let nvc = segue.destination as! UINavigationController
                let detailViewController = nvc.topViewController as! DetailViewController
                //修正不同Detail回傳名稱
                if indexpath.section == 0 {
                    detailViewController.navigationItem.title = appleProduct[indexpath.row] as? String
                    detailViewController.detailItem = appleProduct[indexpath.row] as AnyObject?
                }else {
                    detailViewController.navigationItem.title = bananaProduct[indexpath.row] as? String
                    detailViewController.detailItem = bananaProduct[indexpath.row] as AnyObject?
                }
                
        }
 
        
        
    }
    
    
    

    
    
    }

}
