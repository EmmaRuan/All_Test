//
//  PinkPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/11/13.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import Foundation
class pinkPage: UIViewController{
    
    @IBOutlet weak var Baby: UIButton!
    @IBOutlet weak var Bear: UIButton!
    @IBOutlet weak var Gru: UIButton!
    @IBOutlet weak var Lucy: UIButton!
    
  
        override func viewDidLoad() {
        super.viewDidLoad()
        
        Baby.layer.cornerRadius = 30
        Bear.layer.cornerRadius = 30
        Gru.layer.cornerRadius = 30
        Lucy.layer.cornerRadius = 30
        
    }

    
}
