//
//  PlayMusicPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/10.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer //為取用手機的媒體

class PlayMusicPage: UIViewController, MPMediaPickerControllerDelegate {
    
    var myPlayer:AVAudioPlayer?
    var audioEngine:AVAudioEngine!
    var audioFile:AVAudioFile!
    
    @IBOutlet weak var UIPlay: UIButton!
    
    @IBAction func playsound(_ sender: UIButton) {
        myPlayer?.stop()
        myPlayer?.currentTime = 0.0
        myPlayer?.play()
    }
    
    @IBAction func Quick(_ sender: UIButton) {
        //速度預設為1、最慢0.5、最快 2
        myPlayer?.stop()
        myPlayer?.enableRate = true
        myPlayer?.rate = 2
        myPlayer?.play()

    }
    @IBAction func Slow(_ sender: UIButton) {
        myPlayer?.stop()
        myPlayer?.enableRate = true
        myPlayer?.rate = 0.5
        myPlayer?.play()
    }
    
    @IBAction func normal(_ sender: UIButton) {
        myPlayer?.enableRate = true
        myPlayer?.rate = 1
    }
    
    @IBAction func Replay(_ sender: UIButton) {
        //不停播放設為負值，音量調整0~1之間
        myPlayer?.numberOfLoops = -1
    }
    
    @IBAction func MaxVolume(_ sender: UIButton) {
        myPlayer?.volume = 1
    }
    
    @IBAction func MiniVolume(_ sender: UIButton) {
        myPlayer?.volume = 0.1
    }
    
    @IBAction func MediumVolume(_ sender: UIButton) {
        myPlayer?.volume = 0.6
    }
    
    @IBAction func Stop(_ sender: UIButton) {
        myPlayer?.stop()
        audioEngine.stop()
        audioEngine.reset()
       
    }
    
    //開啟手機媒體櫃（要加info.plist）
    @IBAction func pickMusic(_ sender: AnyObject) {
        let mediapick = MPMediaPickerController(mediaTypes: MPMediaType.anyAudio)
        mediapick.delegate = self
        present(mediapick, animated: true, completion: nil)
        
    }
    
  func mediaPickerDidCancel(_ mediaPicker: MPMediaPickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
        let musicPlayer = MPMusicPlayerController.applicationMusicPlayer
        musicPlayer.play()
        dismiss(animated: true, completion: nil)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIPlay.layer.cornerRadius = 10
        
        //加入專案中的音樂
        if let path = Bundle.main.path(forResource: "Right", ofType: "mp3"){
            
            do{
                myPlayer = try AVAudioPlayer(contentsOf:
                    URL(fileURLWithPath: path))
            }catch {
                
                myPlayer = nil
            }
            
        }
        //聲音特效
        audioEngine = AVAudioEngine()
        let path = Bundle.main.path(forResource: "Right", ofType: "mp3")
        audioFile = try! AVAudioFile(forReading: URL(fileURLWithPath: path!))
        

    }
    
    
    @IBAction func playWithEffect(_ sender: UIButton) {
        audioEngine.stop()
        audioEngine.reset()
        let audioPlayerNode = AVAudioPlayerNode()
        audioEngine.attach(audioPlayerNode)
        
        //加入破音效果
        let addThisEffect = AVAudioUnitDistortion()
        addThisEffect.loadFactoryPreset(.multiEcho2)
        addThisEffect.wetDryMix = 60 //加入破音效果量
        
        /* 其他的效果
         //如果要改音檔的音高(Pitch)
         let addThisEffect = AVAudioUnitTimePitch() //10
         addThisEffect.pitch = 2000 //預設值是1.0，最大值為 2400，最小值為 -2400
         
         //加入延遲效果(Delay)
         //let addThisEffect = AVAudioUnitDelay() //19
         //addThisEffect.delayTime = 2 //預設值是1.0，最大值為 2，最小值為 0
         //addThisEffect.wetDryMix = 100
         
         //加入殘音效果(Reverb)
         let addThisEffect = AVAudioUnitReverb() //20
         addThisEffect.loadFactoryPreset(.cathedral) //21
         addThisEffect.wetDryMix = 100
         */
        
        audioEngine.attach(addThisEffect)
        audioEngine.connect(audioPlayerNode, to: addThisEffect, format: nil)
        audioEngine.connect(addThisEffect, to: audioEngine.outputNode, format: nil)
        audioPlayerNode.scheduleFile(audioFile, at: nil, completionHandler: nil)
        
        do{
            try audioEngine.start()
        }catch{
            print("Error")
        }
        audioPlayerNode.play()
    }
    

    

}
