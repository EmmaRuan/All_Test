//
//  SystemVoicePage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/17.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import AudioToolbox
class SystemVoicePage: UIViewController {
    @IBOutlet weak var TrainView: UIImageView!
    @IBOutlet weak var HornView: UIImageView!
    @IBOutlet weak var BellView: UIImageView!
    

    @IBAction func playsound1(_ sender: UIButton) {
        //收到信件加震動
        AudioServicesPlaySystemSound(1000)
    }
    @IBAction func playsound2(_ sender: UIButton) {
        //火車聲加震動
        AudioServicesPlaySystemSound(1023)
    }
    
    @IBAction func playsound3(_ sender: UIButton) {
        //嘩拉聲加震動
        AudioServicesPlaySystemSound(1021)
    }
    
    @IBAction func playsound4(_ sender: UIButton) {
        //號角聲加震動
        AudioServicesPlaySystemSound(1030)
    }
    
    @IBAction func playsound5(_ sender: UIButton) {
        //鈴鐺音樂加震動
        AudioServicesPlaySystemSound(1028)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //搭配clip to bounds 打勾
        TrainView.layer.cornerRadius = 10
        HornView.layer.cornerRadius = 10
        BellView.layer.cornerRadius = 10
        
        

    }
    

   

}
