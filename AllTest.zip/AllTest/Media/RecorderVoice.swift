//
//  RecorderVoice.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/12.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import AVFoundation

class RecorderVoice: UIViewController, AVAudioRecorderDelegate {
    
    var audioRecorder: AVAudioRecorder?
    var myPlayer:AVAudioPlayer?
    var isRecording = false
    //Timer
    var numberToCount = 0
    var myTimer:Timer?
    
    @objc func counting(){
        numberToCount += 1
        TimerCount.text = "\(numberToCount)"
    }
    
    @IBOutlet weak var TimerCount: UILabel!
    
    //錄音
    let session = AVAudioSession.sharedInstance()

    
    @IBOutlet weak var tableViewFile: UITableView!
    
    @IBAction func recordAudio(_ sender: UIButton) {
        //計時開始
        myTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(RecorderVoice.counting), userInfo: nil, repeats: true)
        
        let documentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] //這邊加[0] ->filePath 的寫法才能正常
        let recordingName = "User.wav"
        let filePath = documentPath + "/" + recordingName
        let fileURL = URL(fileURLWithPath: filePath)
        
        
        do{
            try session.setCategory(AVAudioSession.Category.playAndRecord, mode: .default)
        }catch{
            
        }
        let recordSettings:[String:Any] = [AVEncoderAudioQualityKey: AVAudioQuality.min.rawValue, AVEncoderBitRateKey: 16, AVNumberOfChannelsKey:2, AVSampleRateKey: 44100.0]
        
        do{
            audioRecorder = try AVAudioRecorder(url: fileURL, settings: recordSettings)
        }catch{
            audioRecorder = nil
        }
        audioRecorder?.delegate = self
        audioRecorder?.prepareToRecord()
        audioRecorder?.record()
        isRecording = true
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if (flag){
            do{
                myPlayer = try AVAudioPlayer(contentsOf: recorder.url)
            }catch{
                myPlayer = nil
            }
        }
    }
    
    @IBAction func stopRecord(_ sender: UIButton) {
        //pause Timer
        myTimer?.invalidate()
        print("myTimer?.invalidate()")
        //Reset Timer 會重新計算
        numberToCount = 0
        // TimerCount.text = "0"
        
        if audioRecorder != nil{
            audioRecorder?.stop()
            isRecording = false
            let audioSession = AVAudioSession.sharedInstance()
            do{
                try audioSession.setCategory(AVAudioSession.Category.playback, mode: .default)
            }catch{
                
            }
      
        do {
           try audioSession.setActive(false)
        }catch{
            
        }
    }
    
}
    
    @IBAction func playRecordSound(_ sender: UIButton) {
       
        if myPlayer != nil && isRecording == false{
            myPlayer?.currentTime = 0.0
            myPlayer?.play()
            
        }
    }
    
    @IBAction func stopRecordPlay(_ sender: UIButton) {
        TimerCount.text = " "
        if myPlayer != nil && isRecording == false{
            myPlayer?.stop()
            myPlayer?.currentTime = 0.0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
      
        
    }
    
}
