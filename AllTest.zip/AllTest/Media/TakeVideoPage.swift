//
//  TakeVideoPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/17.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import MobileCoreServices
import Photos
class TakeVideoPage: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var videoPlayer:AVPlayer!
    var imagePicker: UIImagePickerController!
    
    @IBAction func playVideo(_ sender: UIButton) {
        let videoURL = Bundle.main.url(forResource: "ThoseWereTheDays", withExtension: "mp4")
        videoPlayer = AVPlayer(url: videoURL!)
        let videoPlayerController = AVPlayerViewController() //使用內建播放器
        videoPlayerController.player = videoPlayer
        present(videoPlayerController, animated: true, completion: nil)
       
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        }
    
    //錄影
    @IBAction func recordVideo(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let imagePicker = UIImagePickerController() //生成錄影的controller
            imagePicker.sourceType = .camera //設定相機為來源，也可設定成別的
            imagePicker.mediaTypes = [kUTTypeMovie as String] //把錄影結果設成影片
            imagePicker.delegate = self //將viewcontroller設定給UIImagePickerController代理
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    //得到錄影mediaURL與拍照oringinImage的地址
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
       
        //拍照
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
            dismiss(animated: true, completion: nil)
            
        }else{
             let urlOfVideo = info[UIImagePickerController.InfoKey.mediaURL] as? URL
            //影片使用PHPhotoLibrary方法存進相機膠卷
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: urlOfVideo!)}) {(success, error) -> Void in}
            dismiss(animated: true, completion: nil) //順利存擋後移除UIImagePickerController
            
        }
        //增加提示Alert
        let alert = UIAlertController(title: "儲存成功！", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK!", style: .default)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    //點下取消，移除UIImagePickerController
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //照相
    @IBAction func takePicture(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imagePicker = UIImagePickerController()
            imagePicker.sourceType = .camera
            imagePicker.delegate = self
            //imagePicker.showsCameraControls = false //將預設的不顯示，才可客製化
            
            //計算除了UIImagePickerController以外下面高度（客製化）
            let controllerHeight = UIScreen.main.bounds.size.height - UIScreen.main.bounds.size.width * 1.333333
            let myCameraButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.size.width/2 - 95/2, y: UIScreen.main.bounds.size.height - controllerHeight/2 - 95/2, width: 95, height: 95))
            myCameraButton.setImage(UIImage(named: "TakePhotoButtonPressed"), for: .highlighted)
            myCameraButton.addTarget(self, action: #selector(TakeVideoPage.snap), for: .touchUpInside)
            imagePicker.view.addSubview(myCameraButton)
            if imagePicker != nil{
                present(imagePicker, animated: true, completion: nil)

            }
            
        }
    }
    
    @objc func snap(){
        imagePicker?.takePicture()
    }
    
    
}
