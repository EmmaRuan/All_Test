//
//  PickAlbumPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/19.
//  Copyright © 2018 阮宜停. All rights reserved.
//

import UIKit



class PickAlbumPage: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var context:CIContext! //可讓照片濾鏡效果存在這
    
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var keyWord: UITextField!
    @IBOutlet weak var showKeyWord: UILabel!
    @IBOutlet weak var container: UIView!
    
    @IBAction func addNewText(_ sender: UITextField) {
        //將使用者輸入的字顯示在標籤
        showKeyWord.text = keyWord.text
    }
    
    @IBAction func saveImage(_ sender: UIButton) {
        UIGraphicsBeginImageContextWithOptions(container.bounds.size, true, 0.0)
        container.drawHierarchy(in: container.bounds, afterScreenUpdates: true)
        let addTextImage : UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(addTextImage, nil, nil, nil)
        
        //增加提示Alert
        let alert = UIAlertController(title: "儲存成功！", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK!", style: .default)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        keyWord.becomeFirstResponder()
        
        //照片加濾鏡
        let myImage:UIImage = UIImage(named: "Guitar")! //讀圖檔
        let beginImage = CIImage(image: myImage)
        
        //CISepiaTone灰階0.9 ，其他不用設值的-> 像素化CIPixellate、點點畫CIPointillize、六邊形效果CIHexagonalPixellate、酷顏CISpotColor、萬花筒效果CIKalefidoscope、照片、CIPhotoEffectNoir
        let filter = CIFilter(name: "CISepiaTone")!
        filter.setValue(beginImage, forKey: kCIInputImageKey)
        //filter.setValue(0.8, forKey: kCIInputIntensityKey)
        
        let context = CIContext(options: nil)
        let cgimg = context.createCGImage(filter.outputImage!, from: filter.outputImage!.extent)
        let newImage = UIImage(cgImage: cgimg!)
        self.resultImage.image = newImage

    }
    
    // 點擊背景，鍵盤消失
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            self.view.endEditing(false)
        }
    

    //從相簿選影片或照片
    
    @IBAction func selectImage(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType =  .photoLibrary //設定來源為相簿
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let selectImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        resultImage.image = selectImage
        dismiss(animated: true, completion: nil)
    }
    
    //點下取消，移除UIImagePickerController
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

}
