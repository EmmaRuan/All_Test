//
//  ViewController.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func ClickMenu(_ sender: UIBarButtonItem) {
   
        let mainStoryboard = UIStoryboard(
            name: "BabyHome", bundle: nil)
        let PinkPage = mainStoryboard.instantiateViewController(withIdentifier: "pinkView")
        self.navigationController?.pushViewController(PinkPage, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //隱藏navigationItem 返回鍵 (title不設字)
       self.navigationItem.hidesBackButton = true
    }

   
    
}

