//
//  FirstPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation

class FirstPage: UIViewController, UIPopoverPresentationControllerDelegate {
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "showPopover", sender: nil)
    }
    
    
    @IBAction func goHomePage(_ sender: UIBarButtonItem) {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "BabyHome"){
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showPopover" {
            let vc = segue.destination
            //設定浮動畫面大小
            vc.preferredContentSize = CGSize(width: 400, height: 200)
            //取得PopoverPresentationController
            let controller = vc.popoverPresentationController
            if controller != nil{
                //把ViewController設為popover的代理人（delegate）
                controller?.delegate = self as UIPopoverPresentationControllerDelegate
            }
        }
    }
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle{
        return .none //設定style
    }
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
