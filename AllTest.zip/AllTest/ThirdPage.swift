//
//  ThirdPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/10/25.
//  Copyright © 2018年 阮宜停. All rights reserved.
//

import UIKit
import Foundation
class ThirdPage: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var myPageControl: UIPageControl!
    @IBOutlet weak var myScrollView: UIScrollView!
    @IBOutlet weak var myImageView: UIImageView!
 
    //旋轉
    @IBAction func rotationAction(_ sender: UIRotationGestureRecognizer) {
        let radian = sender.rotation //旋轉的徑度
        let degree = radian / .pi //把徑度轉角度
        print("\(degree)")
        myImageView.transform = CGAffineTransform(rotationAngle: radian) //讓ImageView旋轉
    }
    //縮放手勢
    @IBAction func pinchAction(_ sender: UIPinchGestureRecognizer) {
        if sender.state == .began{
            //開始偵測縮放手勢
            print("pinch action start")
        }else if sender.state == .changed{
            print("pinch action changed")
            myImageView.transform = CGAffineTransform(scaleX: 10, y: 10)
        }else if sender.state == .ended{
            //結束偵測縮放手勢
            print("pinch action ended")
        }
    }
    

    
    
    @IBAction func myPageControlAction(_ sender: UIPageControl) {
        print(sender.currentPage)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        myPageControl.currentPage = 1
        //設定顯示內容關寬、高
        myScrollView.contentSize.width = 1080
        myScrollView.contentSize.height = 1080
        //設定最小、最大所縮放比例
        myScrollView.minimumZoomScale = 1.0
        myScrollView.maximumZoomScale = 5.0
        
    }
    
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return myImageView //要放大縮小的圖片
    }

}
