//
//  BallMotionPage.swift
//  AllTest
//
//  Created by 阮宜停 on 2018/12/24.
//  Copyright © 2018 阮宜停. All rights reserved.
//  實作：取用加速感測器，使球自碰撞反彈

import UIKit
import CoreMotion

class BallMotionPage: UIViewController {

    @IBOutlet weak var soccerBall: UIImageView!
    var speedX:UIAccelerationValue = 0
    var speedY:UIAccelerationValue = 0
    let motionManager = CMMotionManager()
    
    @IBAction func StopMotion(_ sender: UIButton) {
        //停止更新加速器資料
        motionManager.stopAccelerometerUpdates()
    }
    @IBAction func ContinueMotion(_ sender: UIButton) {
        motionManager.accelerometerUpdateInterval = 1/60
        
        //檢查是否可用
        if motionManager.isAccelerometerAvailable{
            let operationQ = OperationQueue.current
            motionManager.startAccelerometerUpdates(to: operationQ!, withHandler: {(CMAccelerometerData, Error) in
                //動態設置球位置
                self.speedX += CMAccelerometerData!.acceleration.x
                self.speedY += CMAccelerometerData!.acceleration.y
                var posX = self.soccerBall.center.x + CGFloat(self.speedX)
                var posY = self.soccerBall.center.y - CGFloat(self.speedY)
                //碰到邊框反彈
                if posX<0 {
                    posX=0;
                    //碰到左邊框後以0.4倍的速度反彈
                    self.speedX *= -0.4
                    
                }else if posX > self.view.bounds.size.width {
                    posX=self.view.bounds.size.width
                    //碰到右邊框後以0.4倍的速度反彈
                    self.speedX *= -0.4
                }
                if posY<0 {
                    posY=0
                    //碰到上邊框後以0.3倍的速度反彈
                    self.speedY = -0.3
                } else if posY>self.view.bounds.size.height{
                    posY=self.view.bounds.size.height
                    //碰到下邊框後以1.5倍的速度反彈
                    self.speedY *= -1.5
                }
                self.soccerBall.center = CGPoint(x:posX, y:posY)
            })
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
   /* override func viewDidAppear(_ animated: Bool) {
        //停止更新加速器資料
        motionManager.stopAccelerometerUpdates()
    }*/


}
